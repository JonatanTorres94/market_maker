from collections import defaultdict

from src.domain.execution import Execution


class ExecutionStore:
    def __init__(self):
        self._by_key: dict[tuple[str, str, str, int], Execution] = {}
        self._keys_by_order: dict[tuple[str, int], set[tuple[str, str, str, int]]] = defaultdict(set)

    def upsert(self, execution: Execution) -> bool:
        key = execution.unique_key
        if key in self._by_key:
            return False

        self._by_key[key] = execution
        self._keys_by_order[(execution.symbol, execution.order_id)].add(key)
        return True

    def get(self, exchange: str, account: str, symbol: str, trade_id: int) -> Execution | None:
        return self._by_key.get((exchange, account, symbol, trade_id))

    def list_by_symbol(self, symbol: str) -> list[Execution]:
        return [execution for execution in self._by_key.values() if execution.symbol == symbol]

    def list_by_order(self, symbol: str, order_id: int) -> list[Execution]:
        keys = self._keys_by_order.get((symbol, order_id), set())
        return [self._by_key[key] for key in sorted(keys, key=lambda item: item[3])]

    def total_count(self) -> int:
        return len(self._by_key)
